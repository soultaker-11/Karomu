# Karomu Quick Loan Services (Website)

This repository contains a static website for Karomu Quick Loan Services.
Pages included:
- `index.html` (already in repo)
- `services.html`
- `inventory.html`
- `asset-recovery.html`
- `apply.html`
- `contact.html`
- `css/styles.css`
- `js/scripts.js`

Placeholders to replace:
- `REPLACE_EMAIL` in meta tags and pages
- `REPLACE_PHONE` in `contact.html`
- `REPLACE_ADDRESS` in `contact.html` and map iframe
- `REPLACE_FORM_ENDPOINT` in `apply.html` meta if you want direct submissions

Quick start:
1. Clone the repo:
   git clone https://github.com/soultaker-11/Karomu.git
2. Add the files above into the project (paths as listed).
3. Serve locally:
   python3 -m http.server 8000
   Open http://localhost:8000

Deploy to GitHub Pages:
1. Commit and push changes to `main`.
2. On GitHub, go to Settings → Pages → Source, choose `main` branch and `/ (root)`.
3. Save. Your site will be published at `https://soultaker-11.github.io/Karomu/` (or similar).

Forms:
- The pages use a meta tag `form-endpoint`. Set it to your API endpoint (Netlify, Formspree, or your server).
- If not set, forms use `mailto:` fallback to `REPLACE_EMAIL`.

Assets:
- Replace files in `images/` with your product photos. Recommended sizes:
  - hero/social image: 1200x630
  - inventory images: 1600x900
  - favicon: 32x32

License:
- See `LICENSE` (MIT). Replace owner/year as needed.

If you want, I can:
- Open a pull request with these changes (invite me as a collaborator), or
- Provide a git patch you can apply locally.
